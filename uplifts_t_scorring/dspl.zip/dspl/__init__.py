# Nikita Varganov 2019-2020
# Petr Ryzhonkov 2020
# dspl Machine Learning Library Extensions

# Authors:
# Nikita Varganov <Varganov.N.V@sberbank.ru>
# Petr Ryzhonkov <Ryzhonkov.P.M@sberbank.ru>

# License: 

__version__ = "0.0.1"